package com.boot.util;

import com.boot.dto.CriteriaDTO;
import com.boot.dto.PageDTO;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * 페이징 처리를 위한 유틸리티 클래스
 */
public class PagingUtil {
    
    /**
     * 모델에 페이징 관련 속성을 추가합니다.
     * 
     * @param model 스프링 Model 객체
     * @param criteriaDTO 페이징 기준 정보
     * @param total 전체 항목 수
     * @return 페이지 정보가 담긴 PageDTO 객체
     */
    public static PageDTO setPageAttributes(Model model, CriteriaDTO criteriaDTO, int total) {
        PageDTO pageDTO = new PageDTO(total, criteriaDTO);
        model.addAttribute("pageMaker", pageDTO);
        return pageDTO;
    }
    
    /**
     * 리다이렉트 시 페이징 정보를 유지하기 위한 속성을 추가합니다.
     * 
     * @param rttr 리다이렉트 속성 객체
     * @param criteriaDTO 페이징 기준 정보
     */
    public static void addPagingAttributes(RedirectAttributes rttr, CriteriaDTO criteriaDTO) {
        rttr.addAttribute("pageNum", criteriaDTO.getPageNum());
        rttr.addAttribute("amount", criteriaDTO.getAmount());
    }
}