package com.boot.service;

import java.util.ArrayList;
import org.springframework.stereotype.Service;
import com.boot.dao.PageDAO;
import com.boot.dto.BoardDTO;
import com.boot.dto.CriteriaDTO;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PagingServiceImpl implements PagingService {
    
    private final PageDAO pageDAO;
    
    @Override
    public ArrayList<BoardDTO> listWithPaging(CriteriaDTO criteriaDTO) {
        return pageDAO.listWithPaging(criteriaDTO);
    }
    
    @Override
    public int getTotalCount() {
        return pageDAO.getTotalCount();
    }
}