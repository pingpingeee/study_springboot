package com.boot.config;

import org.springframework.context.annotation.Configuration;

/**
 * 페이징 관련 설정 클래스
 */
@Configuration
public class PagingConfig {
    // @Bean 메서드 제거
    
    // 기본 페이지 크기 설정
    public static final int DEFAULT_PAGE_SIZE = 10;
    
    // 페이지 블록 크기 설정 (한 번에 표시할 페이지 번호 개수)
    public static final int PAGE_BLOCK_SIZE = 10;
}