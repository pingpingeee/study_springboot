package com.boot.component;

import com.boot.dto.CriteriaDTO;
import com.boot.dto.PageDTO;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * 페이징 처리를 위한 컴포넌트
 */
@Component
public class PagingComponent {
    
    /**
     * 목록 페이지에 페이징 정보를 설정합니다.
     * 
     * @param model 모델 객체
     * @param criteriaDTO 페이징 기준 정보
     * @param total 전체 항목 수
     * @return 페이지 정보
     */
    public PageDTO setupPaging(Model model, CriteriaDTO criteriaDTO, int total) {
        PageDTO pageDTO = new PageDTO(total, criteriaDTO);
        model.addAttribute("pageMaker", pageDTO);
        return pageDTO;
    }
    
    /**
     * 상세 페이지에 페이징 정보를 설정합니다.
     * 
     * @param model 모델 객체
     * @param criteriaDTO 페이징 기준 정보
     */
    public void setupDetailPaging(Model model, CriteriaDTO criteriaDTO) {
        model.addAttribute("pageMaker", criteriaDTO);
    }
    
    /**
     * 리다이렉트 시 페이징 정보를 유지합니다.
     * 
     * @param rttr 리다이렉트 속성 객체
     * @param criteriaDTO 페이징 기준 정보
     */
    public void addPagingToRedirect(RedirectAttributes rttr, CriteriaDTO criteriaDTO) {
        rttr.addAttribute("pageNum", criteriaDTO.getPageNum());
        rttr.addAttribute("amount", criteriaDTO.getAmount());
    }
}