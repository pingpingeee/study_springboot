package com.boot.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.boot.component.PagingComponent;
import com.boot.dto.BoardDTO;
import com.boot.dto.CriteriaDTO;
import com.boot.service.PagingService;

@Controller
@Slf4j
public class BoardController {
	
	@Autowired
	private PagingService pagingService;
	@Autowired
	private PagingComponent pagingComponent;
	
	
	@RequestMapping("/list")
    public String list(CriteriaDTO criteriaDTO, Model model) {
        log.info("@# list()");
        log.info("@# criteriaDTO => " + criteriaDTO);
        // 모델에 데이터 추가
//        model.addAttribute("list", list);
        
        // 페이징 처리된 게시글 목록 조회
        ArrayList<BoardDTO> list = pagingService.listWithPaging(criteriaDTO);
        int total = pagingService.getTotalCount();
        
        // 페이징 컴포넌트를 사용하여 페이징 정보 설정
        pagingComponent.setupPaging(model, criteriaDTO, total);
        
        return "list";
    }

}
