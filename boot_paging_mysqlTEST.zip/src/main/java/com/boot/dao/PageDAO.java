package com.boot.dao;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.boot.dto.BoardDTO;
import com.boot.dto.CriteriaDTO;

@Mapper
public interface PageDAO {
    
    /**
     * 페이징 처리된 게시글 목록을 조회합니다.
     * 
     * @param criteriaDTO 페이징 기준 정보
     * @return 게시글 목록
     */
    ArrayList<BoardDTO> listWithPaging(CriteriaDTO criteriaDTO);
    
    /**
     * 전체 게시글 수를 조회합니다.
     * 
     * @return 전체 게시글 수
     */
    int getTotalCount();
}